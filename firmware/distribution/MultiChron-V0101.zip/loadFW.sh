sudo avrdude -p atmega328p -c usbtiny -B 1 -U flash:w:MultiChron.hex -U eeprom:w:MultiChron.eep
