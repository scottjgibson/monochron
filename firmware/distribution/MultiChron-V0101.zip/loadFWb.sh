sudo avrdude -p atmega328p -c usbtiny -B 1 -U flash:w:MultiChronB.hex -U eeprom:w:MultiChronB.eep
