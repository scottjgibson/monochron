MultiChron

Loading the firmware.
Please be advised that this program stores values in EEPROM memory,
As such, EEPROM must be loaded with each new version.
Please use or examine the attached loadfw.bat or loadfw.sh (assumes use of a tinyusb programmer)
Failure to load the EEPROM will result in a blank screen and continuous beeps.
This may be corrected by loaded loading the EEPROM.

Version 1.1
9/10/2010
Added TimesSqaureChron, Coding Dataman, Simulates the Scrolling Marquee of Times Square
GPS Setup, GPS module will be detected and used if present, Coding Dataman, Making it work CaitSitch
Instructions on adding the GPS module to stock MonoChron at http://crjones.com/adamods
Code highly optimized, Thank you CaitSith!
Modules may be dropped in or out, Thank you again CaitSith!
Added Distribution Folder for creating a more detailed distro zip
Added ReadMe

Version 1.1b
9/10/2010
This is an alternate version of the 1.1 build
Added DeathChron, Coding CaithSith,  A CountDown Clock 
Includes GPS Module & RattChron
Use LoadFWb.bat or LoadFWb.sh


Version 1.0
8/14/2010
Initial Version
InvaderCron
RattChron
SevenChron
XDaliChron
About
Random
Rotate

