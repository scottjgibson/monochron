MultiChron

Loading the firmware.
Please be advised that this program stores values in EEPROM memory,
As such, EEPROM must be loaded with each new version.
Please use or examine the attached loadfw.bat or loadfw.sh (assumes use of a tinyusb programmer)
Failure to load the EEPROM will result in a blank screen and continuous beeps.
This may be corrected by loaded loading the EEPROM.

Wish List for 1.2:
Daylight Savings Time - Automatically adjust GPS for Daylight Savings time
AutoDim - Audodim click based on added light sensor.
TimerChron - A Count Up Timer that reads external inputs for start/stop.
DissolveChron - A Chron that time melts in and out as mosaic panels.


Version 1.1
9/10/2010
Added TimesSqaureChron, Coding Dataman, Simulates the Scrolling Marquee of Times Square
GPS Setup, GPS module will be detected and used if present, Coding Dataman, Making it work CaitSith
Instructions on adding the GPS module to stock MonoChron at http://crjones.com/adamods
Code highly optimized, Thank you CaitSith!
Modules may be dropped in or out, Thank you again CaitSith!
Added Distribution Folder for creating a more detailed distro zip
Added ReadMe
-->KNOWN ISSUE: TimeZone Adjust is just that, Adjust for your TimeZone, please account for Daylight Savings Time,
The GPS Module Currently does not do that.  You must account for this in your adjust.  
IE: If you're in Nevada, your TimeZone adjust is GMT -8.  Subtract 1 for Daylight Savings Time: -7.
When Daylight Savings Time ends, Adjust back to -8.
 
Version 1.1b
9/10/2010
This is an alternate version of the 1.1 build
Added DeathChron, Coding CaitSith,  A CountDown Clock 
Includes GPS Module & RattChron
Use LoadFWb.bat or LoadFWb.sh


Version 1.0
8/14/2010
Initial Version, Coding by Dataman, Optimization (made it all fit) by CaitSith.
InvaderCron
RattChron
SevenChron
XDaliChron
About
Random
Rotate

